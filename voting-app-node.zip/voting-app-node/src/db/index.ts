export { connect } from "./db";
